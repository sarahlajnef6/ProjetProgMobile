const int LEDS[] = {18, 19, 21};
const int NB_LEDS = 3;

void setup() {
  for (int i = 0; i < NB_LEDS; i++) {
    pinMode(LEDS[i], OUTPUT);
  }
}

void loop() {
  for (int i = 0; i < NB_LEDS; i++) {
    digitalWrite(LEDS[i], HIGH); // Allume cette LED
    delay(500);
    digitalWrite(LEDS[i], LOW);  // Éteint avant de passer à la suivante
  }
}