#define LED_PIN 19

void setup(void) {
    pinMode(LED_PIN, OUTPUT);
}

void loop(void) {
    analogWrite(LED_PIN, 50); // Luminosité maximale
    delay(500);
    analogWrite(LED_PIN, 100); // Luminosité maximale
    delay(500);
    analogWrite(LED_PIN, 150); // Luminosité maximale
    delay(500);
    analogWrite(LED_PIN, 200); // Luminosité maximale
    delay(500);
    analogWrite(LED_PIN, 255); // Luminosité maximale
    delay(500);
    analogWrite(LED_PIN, 0);   // LED éteinte
    delay(500);
}