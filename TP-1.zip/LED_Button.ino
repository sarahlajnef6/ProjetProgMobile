const int LED_PIN = 18;
const int BUTTON_PIN = 19;

void setup() {
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUTTON_PIN, INPUT_PULLUP); // Bouton entre GPIO 19 et GND
}

void loop() {
  bool boutonAppuye = (digitalRead(BUTTON_PIN) == LOW);
  digitalWrite(LED_PIN, boutonAppuye ? HIGH : LOW);
}