const int LED_PIN = 19; 
const int POT_PIN = 34; 

void setup() {
  pinMode(LED_PIN, OUTPUT);
}

void loop() {
  int valeurPot = analogRead(POT_PIN);         
  int luminosite = map(valeurPot, 0, 4095, 0, 255);

  analogWrite(LED_PIN, luminosite);            
  delay(10);
}